package com.mycom.library.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mycom.library.dao.BookDao;
import com.mycom.library.pojo.Book;
//import com.sun.istack.internal.logging.Logger;
//The import com.sun.istack.internal cannot be resolved


public class BookDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	public BookDeleteServlet() {
		super();
		// TODO Auto-generated constructor stub
	}


	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		BookDao bookDao = new BookDao();
		Book book = new Book();
		int rows = 0;
		int id;
		String name, author;
		float price;
		HttpSession session=request.getSession();
		id = Integer.parseInt(request.getParameter("id"));
		PrintWriter out = response.getWriter();
		out.println("Book id " + id);
		try {
			rows = bookDao.deleteBook(id);
		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
		if( rows == 1) {
		//	Logger logger = Logger.getLogger(getClass());
			//logger.info("Book data successfully deleted");
			session.setAttribute("rows",rows);
			System.out.println("Book data successfully deleted");
		} else {
			//Logger logger = Logger.getLogger(getClass());
			//logger.info("Book data could not delete");
			session.setAttribute("rows",rows);
                    System.out.println("Book data could not delete");
		}
		RequestDispatcher reqDisp = 
				request.getRequestDispatcher("/delete.jsp");
		reqDisp.forward(request, response);

	}
}


