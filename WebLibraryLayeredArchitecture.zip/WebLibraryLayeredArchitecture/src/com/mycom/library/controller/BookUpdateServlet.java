package com.mycom.library.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mycom.library.dao.BookDao;
import com.mycom.library.pojo.Book;
//import com.sun.istack.internal.logging.Logger;

public class BookUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public BookUpdateServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BookDao bookDao = new BookDao();
		int rows = 0;
		int id;
		HttpSession session=request.getSession();

		id = Integer.parseInt(request.getParameter("id"));
		try {
			rows = bookDao.updateBook(id);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if( rows == 1) {
			//Logger logger = Logger.getLogger(getClass());
			//logger.info("Book data successfully updated");
			session.setAttribute("rows",rows);
			System.out.println("Book data successfully updated");
		} else {
			//Logger logger = Logger.getLogger(getClass());
			//logger.info("Book data could not update");
			session.setAttribute("rows",rows);
			System.out.println("Book data could not update");

		}
		RequestDispatcher reqDisp = 
				request.getRequestDispatcher("/update.jsp");
		reqDisp.forward(request, response);

	}
}


